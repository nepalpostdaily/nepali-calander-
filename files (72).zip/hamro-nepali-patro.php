<?php
/**
 * Plugin Name: Hamro Nepali Patro
 * Plugin URI: https://yourwebsite.com/hamro-nepali-patro
 * Description: A beautiful Nepali calendar (BS) with events, date converter, and panchang information.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * Text Domain: hamro-nepali-patro
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

define('HNP_VERSION', '1.0.0');
define('HNP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('HNP_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include classes
require_once HNP_PLUGIN_DIR . 'includes/class-hamro-nepali-patro.php';
require_once HNP_PLUGIN_DIR . 'admin/class-hamro-nepali-patro-admin.php';

// Plugin init
function hamro_nepali_patro_init() {
    load_plugin_textdomain('hamro-nepali-patro', false, dirname(plugin_basename(__FILE__)) . '/languages');
    new Hamro_Nepali_Patro();

    if (is_admin()) {
        new Hamro_Nepali_Patro_Admin();
    }
}
add_action('plugins_loaded', 'hamro_nepali_patro_init');

// Activation
register_activation_hook(__FILE__, 'hamro_nepali_patro_activate');
function hamro_nepali_patro_activate() {
    global $wpdb;
    $table = $wpdb->prefix . 'hnp_events';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        bs_year smallint(4) NOT NULL,
        bs_month tinyint(2) NOT NULL,
        bs_day tinyint(2) NOT NULL,
        title text NOT NULL,
        description text,
        event_type varchar(50) DEFAULT 'festival',
        PRIMARY KEY  (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    add_option('hnp_settings', [
        'theme_color' => '#e53e3e',
        'default_language' => 'ne',
        'show_events' => 'yes',
        'show_panchang' => 'yes'
    ]);
}
register_deactivation_hook(__FILE__, function(){});

// Shortcode
add_shortcode('hamro_nepali_patro', function($atts) {
    $atts = shortcode_atts([
        'theme' => '',
        'language' => '',
        'view' => 'calendar'
    ], $atts, 'hamro_nepali_patro');
    $settings = get_option('hnp_settings', []);
    ob_start();
    include HNP_PLUGIN_DIR . 'public/partials/hamro-nepali-patro-public-display.php';
    return ob_get_clean();
});