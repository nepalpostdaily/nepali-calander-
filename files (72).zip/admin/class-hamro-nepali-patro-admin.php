<?php
if (!defined('ABSPATH')) exit;

class Hamro_Nepali_Patro_Admin {
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
    }
    public function add_admin_menu() {
        add_menu_page('Hamro Nepali Patro', 'Nepali Patro', 'manage_options',
            'hamro-nepali-patro', [$this, 'display_admin_page'], 'dashicons-calendar-alt', 30);
        add_submenu_page('hamro-nepali-patro', 'Settings', 'Settings', 'manage_options',
            'hamro-nepali-patro-settings', [$this, 'display_settings_page']);
    }
    public function register_settings() {
        register_setting('hnp_settings_group', 'hnp_settings');
        add_settings_section('hnp_general_settings', 'General Settings', function(){}, 'hamro-nepali-patro-settings');
        add_settings_field('hnp_theme_color', 'Theme Color', [$this, 'theme_color_callback'],
            'hamro-nepali-patro-settings', 'hnp_general_settings');
    }
    public function theme_color_callback() {
        $settings = get_option('hnp_settings', []);
        $color = isset($settings['theme_color']) ? $settings['theme_color'] : '#e53e3e';
        echo '<input type="text" name="hnp_settings[theme_color]" value="' . esc_attr($color) . '" />';
    }
    public function display_admin_page() {
        echo '<div class="wrap"><h1>Hamro Nepali Patro</h1><p>Welcome!</p></div>';
    }
    public function display_settings_page() {
        ?>
        <div class="wrap">
            <h1>Hamro Nepali Patro Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('hnp_settings_group'); do_settings_sections('hamro-nepali-patro-settings'); submit_button(); ?>
            </form>
        </div>
        <?php
    }
}