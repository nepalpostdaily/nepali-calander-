<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get events from database
global $wpdb;
$table_name = $wpdb->prefix . 'hnp_events';
$events = $wpdb->get_results("SELECT * FROM $table_name ORDER BY bs_year, bs_month, bs_day", ARRAY_A);
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="hnp-admin-container">
        <div class="hnp-admin-tabs">
            <a href="#add-event" class="hnp-tab active"><?php _e('Add Event', 'hamro-nepali-patro'); ?></a>
            <a href="#manage-events" class="hnp-tab"><?php _e('Manage Events', 'hamro-nepali-patro'); ?></a>
            <a href="#import-export" class="hnp-tab"><?php _e('Import/Export', 'hamro-nepali-patro'); ?></a>
        </div>
        
        <div class="hnp-tab-content" id="add-event-content">
            <h2><?php _e('Add New Event', 'hamro-nepali-patro'); ?></h2>
            
            <form id="hnp-add-event-form">
                <input type="hidden" id="event_id" value="0">
                
                <div class="hnp-form-row">
                    <div class="hnp-form-group">
                        <label for="bs_year"><?php _e('Year (BS)', 'hamro-nepali-patro'); ?></label>
                        <select id="bs_year" required>
                            <?php for ($year = 2070; $year <= 2090; $year++) : ?>
                                <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                    <div class="hnp-form-group">
                        <label for="bs_month"><?php _e('Month', 'hamro-nepali-patro'); ?></label>
                        <select id="bs_month" required>
                            <option value="0"><?php _e('Baisakh', 'hamro-nepali-patro'); ?></option>
                            <option value="1"><?php _e('Jestha', 'hamro-nepali-patro'); ?></option>
                            <option value="2"><?php _e('Ashar', 'hamro-nepali-patro'); ?></option>
                            <option value="3"><?php _e('Shrawan', 'hamro-nepali-patro'); ?></option>
                            <option value="4"><?php _e('Bhadra', 'hamro-nepali-patro'); ?></option>
                            <option value="5"><?php _e('Ashwin', 'hamro-nepali-patro'); ?></option>
                            <option value="6"><?php _e('Kartik', 'hamro-nepali-patro'); ?></option>
                            <option value="7"><?php _e('Mangsir', 'hamro-nepali-patro'); ?></option>
                            <option value="8"><?php _e('Poush', 'hamro-nepali-patro'); ?></option>
                            <option value="9"><?php _e('Magh', 'hamro-nepali-patro'); ?></option>
                            <option value="10"><?php _e('Falgun', 'hamro-nepali-patro'); ?></option>
                            <option value="11"><?php _e('Chaitra', 'hamro-nepali-patro'); ?></option>
                        </select>
                    </div>
                    
                    <div class="hnp-form-group">
                        <label for="bs_day"><?php _e('Day', 'hamro-nepali-patro'); ?></label>
                        <select id="bs_day" required>
                            <?php for ($day = 1; $day <= 32; $day++) : ?>
                                <option value="<?php echo $day; ?>"><?php echo $day; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                
                <div class="hnp-form-row">
                    <div class="hnp-form-group full-width">
                        <label for="title"><?php _e('Event Title', 'hamro-nepali-patro'); ?></label>
                        <input type="text" id="title" required>
                    </div>
                </div>
                
                <div class="hnp-form-row">
                    <div class="hnp-form-group full-width">
                        <label for="description"><?php _e('Description (Optional)', 'hamro-nepali-patro'); ?></label>
                        <textarea id="description" rows="3"></textarea>
                    </div>
                </div>
                
                <div class="hnp-form-row">
                    <div class="hnp-form-group">
                        <label for="event_type"><?php _e('Event Type', 'hamro-nepali-patro'); ?></label>
                        <select id="event_type">
                            <option value="festival"><?php _e('Festival', 'hamro-nepali-patro'); ?></option>
                            <option value="holiday"><?php _e('Holiday', 'hamro-nepali-patro'); ?></option>
                            <option value="event"><?php _e('Event', 'hamro-nepali-patro'); ?></option>
                        </select>
                    </div>
                </div>
                
                <div class="hnp-form-row">
                    <button type="submit" class="button button-primary"><?php _e('Save Event', 'hamro-nepali-patro'); ?></button>
                    <button type="button" id="reset-form" class="button"><?php _e('Reset', 'hamro-nepali-patro'); ?></button>
                </div>
            </form>
        </div>
        
        <div class="hnp-tab-content" id="manage-events-content" style="display: none;">
            <h2><?php _e('Manage Events', 'hamro-nepali-patro'); ?></h2>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Date (BS)', 'hamro-nepali-patro'); ?></th>
                        <th><?php _e('Title', 'hamro-nepali-patro'); ?></th>
                        <th><?php _e('Type', 'hamro-nepali-patro'); ?></th>
                        <th><?php _e('Actions', 'hamro-nepali-patro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($events)) : ?>
                        <tr>
                            <td colspan="4"><?php _e('No events found.', 'hamro-nepali-patro'); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($events as $event) : ?>
                            <tr>
                                <td>
                                    <?php 
                                    $months = array(
                                        __('Baisakh', 'hamro-nepali-patro'),
                                        __('Jestha', 'hamro-nepali-patro'),
                                        __('Ashar', 'hamro-nepali-patro'),
                                        __('Shrawan', 'hamro-nepali-patro'),
                                        __('Bhadra', 'hamro-nepali-patro'),
                                        __('Ashwin', 'hamro-nepali-patro'),
                                        __('Kartik', 'hamro-nepali-patro'),
                                        __('Mangsir', 'hamro-nepali-patro'),
                                        __('Poush', 'hamro-nepali-patro'),
                                        __('Magh', 'hamro-nepali-patro'),
                                        __('Falgun', 'hamro-nepali-patro'),
                                        __('Chaitra', 'hamro-nepali-patro')
                                    );
                                    echo $event['bs_day'] . ' ' . $months[$event['bs_month']] . ' ' . $event['bs_year'];
                                    ?>
                                </td>
                                <td><?php echo esc_html($event['title']); ?></td>
                                <td><?php echo esc_html(ucfirst($event['event_type'])); ?></td>
                                <td>
                                    <button class="button edit-event" data-event="<?php echo esc_attr(json_encode($event)); ?>"><?php _e('Edit', 'hamro-nepali-patro'); ?></button>
                                    <button class="button delete-event" data-id="<?php echo $event['id']; ?>"><?php _e('Delete', 'hamro-nepali-patro'); ?></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="hnp-tab-content" id="import-export-content" style="display: none;">
            <h2><?php _e('Import/Export Events', 'hamro-nepali-patro'); ?></h2>
            
            <div class="hnp-admin-card">
                <h3><?php _e('Import Events', 'hamro-nepali-patro'); ?></h3>
                <p><?php _e('Paste your JSON data below to import events. The format should be an array of objects with bs_year, bs_month, bs_day, title, and optional description and event_type fields.', 'hamro-nepali-patro'); ?></p>
                
                <textarea id="import-json" rows="10" class="large-text code" placeholder='[
    {
        "bs_year": 2080,
        "bs_month": 0,
        "bs_day": 1,
        "title": "नयाँ वर्ष",
        "event_type": "holiday"
    },
    {
        "bs_year": 2080,
        "bs_month": 1,
        "bs_day": 15,
        "title": "गणतन्त्र दिवस",
        "event_type": "holiday"
    }
]'></textarea>
                
                <button id="import-events-btn" class="button button-primary"><?php _e('Import Events', 'hamro-nepali-patro'); ?></