<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="hnp-admin-container">
        <div class="hnp-admin-header">
            <h2><?php _e('Welcome to Hamro Nepali Patro', 'hamro-nepali-patro'); ?></h2>
            <p><?php _e('A beautiful Nepali calendar plugin with events, date converter, and panchang information.', 'hamro-nepali-patro'); ?></p>
        </div>
        
        <div class="hnp-admin-content">
            <div class="hnp-admin-card">
                <h3><?php _e('Quick Start', 'hamro-nepali-patro'); ?></h3>
                <p><?php _e('Use the shortcode below to display the Nepali calendar on any page or post:', 'hamro-nepali-patro'); ?></p>
                <code>[hamro_nepali_patro]</code>
                
                <p><?php _e('You can also customize the shortcode with these attributes:', 'hamro-nepali-patro'); ?></p>
                <ul>
                    <li><code>theme</code> - <?php _e('Set a custom theme color (e.g., #ff0000)', 'hamro-nepali-patro'); ?></li>
                    <li><code>language</code> - <?php _e('Set the default language (ne or en)', 'hamro-nepali-patro'); ?></li>
                    <li><code>view</code> - <?php _e('Set the default view (calendar, converter, or panchang)', 'hamro-nepali-patro'); ?></li>
                </ul>
                
                <p><?php _e('Example:', 'hamro-nepali-patro'); ?></p>
                <code>[hamro_nepali_patro theme="#4299e1" language="en" view="converter"]</code>
            </div>
            
            <div class="hnp-admin-card">
                <h3><?php _e('Features', 'hamro-nepali-patro'); ?></h3>
                <ul>
                    <li><?php _e('Nepali Calendar (BS) View with Nepali numerals', 'hamro-nepali-patro'); ?></li>
                    <li><?php _e('Month/Year Navigation', 'hamro-nepali-patro'); ?></li>
                    <li><?php _e('Today\'s Highlight', 'hamro-nepali-patro'); ?></li>
                    <li><?php _e('Events and Festivals Display', 'hamro-nepali-patro'); ?></li>
                    <li><?php _e('Responsive UI', 'hamro-nepali-patro'); ?></li>
                    <li><?php _e('Language Toggle (Nepali/English)', 'hamro-nepali-patro'); ?></li>
                    <li><?php _e('Nepali Date Converter (BS ↔ AD)', 'hamro-nepali-patro'); ?></li>
                    <li><?php _e('Tithi & Panchang Information', 'hamro-nepali-patro'); ?></li>
                </ul>
            </div>
            
            <div class="hnp-admin-card">
                <h3><?php _e('Need Help?', 'hamro-nepali-patro'); ?></h3>
                <p><?php _e('Check out these resources:', 'hamro-nepali-patro'); ?></p>
                <ul>
                    <li><a href="#"><?php _e('Documentation', 'hamro-nepali-patro'); ?></a></li>
                    <li><a href="#"><?php _e('Support Forum', 'hamro-nepali-patro'); ?></a></li>
                    <li><a href="#"><?php _e('Report a Bug', 'hamro-nepali-patro'); ?></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>