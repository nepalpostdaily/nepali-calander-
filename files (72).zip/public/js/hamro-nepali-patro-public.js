jQuery(document).ready(function($) {
    // === CONFIG ===
    const months_ne = ['बैशाख','जेठ','असार','साउन','भदौ','असोज','कार्तिक','मंसिर','पुष','माघ','फागुन','चैत्र'];
    const months_en = ['Baisakh','Jestha','Ashadh','Shrawan','Bhadra','Ashwin','Kartik','Mangsir','Poush','Magh','Falgun','Chaitra'];
    const days_en = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    const days_ne = ['आइत','सोम','मंगल','बुध','बिही','शुक्र','शनि'];
    const todayAD = new Date();
    // AD 2025-05-22 = 2082-02-08 (Jestha 8, 2082)
    // For demo, always use this date as "today"
    const today_bs = {year:2082,month:1,day:8}; // month 0=Baishakh

    let lang = 'ne'; // default language
    let selectedDate = {...today_bs};
    let currentYear = today_bs.year, currentMonth = today_bs.month;
    let monthDates = [], allYearData = []; // cache

    // === UTILS ===
    function toNp(num) { return String(num).replace(/\d/g, d=>'०१२३४५६७८९'[d]); }
    function getMonths() { return lang==='ne' ? months_ne : months_en; }
    function getDays() { return lang==='ne' ? days_ne : days_en; }
    function formatDay(d) { return lang==='ne' ? toNp(d) : d; }
    function formatMonth(m) { return getMonths()[m]; }
    function formatYear(y) { return lang==='ne' ? toNp(y) : y; }

    // === API ===
    function fetchYear(year, cb) {
        // cache
        if (allYearData[year]) return cb(allYearData[year]);
        $('.hamro-nepali-patro-container').addClass('hnp-loading');
        fetch("https://api.saralpatro.com/graphql", {
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({query:`
            { dates(bsYear:${year}) {
                bsDay bsMonth bsYear adDay adMonth adYear bsDayNp bsMonthNp bsYearNp
                weekday weekdayStrEn weekdayStrNp bsMonthStrEn bsMonthStrNp adMonthStrEn adMonthStrNp
                isHoliday tithiCode tithiStrNp tithiStrEn
                astral {sunrise{hour minute} sunset{hour minute}}
                specialDays {bratabanda bibaha rudri grihaprabesh}
                events {strEn strNp isHoliday}
            }}`}),
            method: "POST"
        }).then(r=>r.json()).then(res=>{
            const data = res.data.dates;
            allYearData[year] = data;
            cb(data);
            $('.hamro-nepali-patro-container').removeClass('hnp-loading');
        });
    }
    function getMonthDates(data, y, m) { // m: 0-based
        return data.filter(d=>d.bsYear===y && d.bsMonth===m+1);
    }
    function findDateObj(bsYear, bsMonth, bsDay) {
        if (!allYearData[bsYear]) return null;
        return allYearData[bsYear].find(d=>d.bsYear===bsYear&&d.bsMonth===bsMonth+1&&d.bsDay===bsDay);
    }
    function isTodayCell(d) {
        return d.bsYear===today_bs.year && d.bsMonth===today_bs.month+1 && d.bsDay===today_bs.day;
    }

    // === RENDER ===
    function renderCalendar() {
        // Main Layout
        $('.hamro-nepali-patro-container').html(`
        <div class="hnp-main">
            <div class="hnp-cal-header">
                <div class="hnp-date-title"></div>
                <div class="hnp-header-tools">
                    <button class="hnp-lang-btn hnp-lang-ne${lang==='ne'?' active':''}">नेपाली</button>
                    <button class="hnp-lang-btn hnp-lang-en${lang==='en'?' active':''}">English</button>
                </div>
            </div>
            <div class="hnp-summary">
                <div class="hnp-summary-block hnp-summary-day"></div>
                <div class="hnp-summary-block hnp-summary-events"></div>
                <div class="hnp-summary-block hnp-summary-special"></div>
            </div>
            <div class="hnp-main-row">
                <div class="hnp-calendar-block">
                    <div class="hnp-month-nav">
                        <button class="hnp-nav-prev">&lt;</button>
                        <span class="hnp-month-label"></span>
                        <button class="hnp-nav-next">&gt;</button>
                    </div>
                    <table class="hnp-calendar-table"></table>
                </div>
                <div class="hnp-details-block"></div>
            </div>
        </div>
        `);

        // Language toggle
        $('.hnp-lang-btn').off('click').on('click', function(){
            lang = $(this).hasClass('hnp-lang-ne')?'ne':'en';
            renderCalendar();
        });

        // Month Navigation
        $('.hnp-nav-prev').off('click').on('click', function(){
            currentMonth -= 1;
            if (currentMonth<0) { currentMonth=11; currentYear--; }
            selectedDate = {year:currentYear,month:currentMonth,day:1};
            loadMonth();
        });
        $('.hnp-nav-next').off('click').on('click', function(){
            currentMonth += 1;
            if (currentMonth>11) { currentMonth=0; currentYear++; }
            selectedDate = {year:currentYear,month:currentMonth,day:1};
            loadMonth();
        });

        // Show current AD date on top right
        $('.hnp-date-title').html(`<span>${formatDay(selectedDate.day)} ${formatMonth(selectedDate.month)} ${formatYear(selectedDate.year)}</span>
            <span class="hnp-ad-date">${toAD(selectedDate.year, selectedDate.month, selectedDate.day)}</span>`);

        // Load year
        loadMonth();
    }

    function loadMonth() {
        fetchYear(currentYear, function(data){
            monthDates = getMonthDates(data, currentYear, currentMonth);

            // Calculate grid: first day weekday
            let firstWeekday = (monthDates[0].weekday+6)%7; // 0=Sun
            let grid = [];
            let week = [];
            for (let i=0; i<firstWeekday; ++i) week.push(null);
            monthDates.forEach(d=>{
                week.push(d);
                if (week.length===7) { grid.push(week); week=[]; }
            });
            if (week.length) while(week.length<7)week.push(null),grid.push(week);

            // Render month label
            $('.hnp-month-label').html(`${formatMonth(currentMonth)} ${formatYear(currentYear)}`);

            // Render table
            let calHTML = `<thead><tr>${getDays().map(d=>`<th>${d}</th>`).join('')}</tr></thead><tbody>`;
            grid.forEach(row=>{
                calHTML += '<tr>';
                row.forEach(cell=>{
                    if (!cell) calHTML+='<td class="hnp-empty"></td>';
                    else {
                        let isToday = isTodayCell(cell);
                        let isSelected = (cell.bsDay===selectedDate.day);
                        let classes = 'hnp-cell';
                        if (isToday) classes+=' hnp-today';
                        if (isSelected) classes+=' hnp-selected';
                        if (cell.isHoliday) classes+=' hnp-holiday';
                        if (cell.events && cell.events.some(e=>e.isHoliday)) classes+=' hnp-event-holiday';
                        calHTML += `<td class="${classes}" data-bsday="${cell.bsDay}">
                            <div class="hnp-cell-main">
                                <span class="hnp-day">${formatDay(cell.bsDay)}</span>
                                <span class="hnp-ad">${cell.adDay}/${cell.adMonth}</span>
                            </div>
                            <div class="hnp-tithi-mini">${lang==='ne'?cell.tithiStrNp:cell.tithiStrEn||''}</div>
                            <div class="hnp-events-mini">${cell.events?.map(e=>`<span class="${e.isHoliday?'hnp-holiday':''}">${lang==='ne'?e.strNp:e.strEn}</span>`).join('<br>')||''}</div>
                        </td>`;
                    }
                });
                calHTML += '</tr>';
            });
            calHTML += '</tbody>';
            $('.hnp-calendar-table').html(calHTML);

            // Clickable blocks
            $('.hnp-cell').off('click').on('click', function(){
                let day = parseInt($(this).attr('data-bsday'));
                selectedDate = {year:currentYear,month:currentMonth,day:day};
                renderCalendar();
            });

            // Highlight selected cell
            $(`.hnp-cell[data-bsday="${selectedDate.day}"]`).addClass('hnp-selected');

            // Summary blocks (top)
            let sel = findDateObj(selectedDate.year,selectedDate.month,selectedDate.day);
            $('.hnp-summary-day').html(`
                <div><b>${lang==='ne'?sel.weekdayStrNp:sel.weekdayStrEn}</b></div>
                <div>${lang==='ne'?'तिथि':'Tithi'}: ${lang==='ne'?sel.tithiStrNp:sel.tithiStrEn}</div>
                <div>${lang==='ne'?'सूर्योदय':'Sunrise'}: ${formatTime(sel.astral?.sunrise)}</div>
                <div>${lang==='ne'?'सूर्यास्त':'Sunset'}: ${formatTime(sel.astral?.sunset)}</div>
            `);
            $('.hnp-summary-events').html(`
                <div><b>${lang==='ne'?'आजका कार्यक्रम':'Today\'s Events'}</b></div>
                <div>${(sel.events?.map(e=>lang==='ne'?e.strNp:e.strEn).join('<br>')) || (lang==='ne'?'कुनै कार्यक्रम छैन':'No events')}</div>
            `);
            $('.hnp-summary-special').html(`
                <div><b>${lang==='ne'?'विशेष दिन':'Special Days'}</b></div>
                <div>${formatSpecial(sel.specialDays) || (lang==='ne'?'विशेष दिन छैन':'No special days')}</div>
            `);

            // Details block (right)
            $('.hnp-details-block').html(`
                <div class="hnp-details-title">${lang==='ne'?sel.weekdayStrNp:sel.weekdayStrEn}, ${formatDay(sel.bsDay)} ${formatMonth(sel.bsMonth-1)} ${formatYear(sel.bsYear)}</div>
                <div class="hnp-details-sub">${lang==='ne'?sel.tithiStrNp:sel.tithiStrEn} / ${formatDay(sel.adDay)} ${sel.adMonthStrEn} ${sel.adYear}</div>
                <div>${lang==='ne'?'सूर्योदय':'Sunrise'}: ${formatTime(sel.astral?.sunrise)} | ${lang==='ne'?'सूर्यास्त':'Sunset'}: ${formatTime(sel.astral?.sunset)}</div>
                <div class="hnp-details-section">
                    <b>${lang==='ne'?'विशेष दिन':'Special Days'}:</b> ${formatSpecial(sel.specialDays) || (lang==='ne'?'छैन':'None')}
                </div>
                <div class="hnp-details-section">
                    <b>${lang==='ne'?'कार्यक्रमहरू':'Events'}:</b>
                    ${(sel.events?.map(e=>`<div class="hnp-details-event ${e.isHoliday?'hnp-holiday':''}">${lang==='ne'?e.strNp:e.strEn}</div>`).join('')) || (lang==='ne'?'छैन':'None')}
                </div>
            `);
        });
    }

    function formatTime(obj) {
        if (!obj) return '';
        let h = obj.hour, m = obj.minute;
        if (lang==='ne') return toNp(h)+':'+toNp(m.toString().padStart(2,'0'));
        return `${h}:${m.toString().padStart(2,'0')}`;
    }
    function formatSpecial(s) {
        if (!s) return '';
        let out = [];
        if (s.bratabanda) out.push(lang==='ne'?'ब्रतबन्ध':'Bratabanda');
        if (s.bibaha) out.push(lang==='ne'?'विवाह':'Bibaha');
        if (s.rudri) out.push(lang==='ne'?'रुद्री':'Rudri');
        if (s.grihaprabesh) out.push(lang==='ne'?'गृहप्रवेश':'Grihaprabesh');
        return out.map(x=>`<span class="hnp-special">${x}</span>`).join(' ');
    }
    function toAD(bsYear, bsMonth, bsDay) {
        // use selected cell data if available
        let obj = findDateObj(bsYear, bsMonth, bsDay);
        if (obj) return `${obj.adDay} ${obj.adMonthStrEn} ${obj.adYear}`;
        return '';
    }

    // === INITIALIZE ===
    renderCalendar();
});