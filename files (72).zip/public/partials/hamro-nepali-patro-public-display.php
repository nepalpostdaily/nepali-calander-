<?php
if (!defined('ABSPATH')) exit;
$settings = get_option('hnp_settings', []);
$theme_color = isset($settings['theme_color']) ? $settings['theme_color'] : '#e53e3e';
$default_language = isset($settings['default_language']) ? $settings['default_language'] : 'ne';
$show_events = isset($settings['show_events']) ? $settings['show_events'] : 'yes';
$show_panchang = isset($settings['show_panchang']) ? $settings['show_panchang'] : 'yes';
?>
<div class="hamro-nepali-patro-container"
     data-theme="<?php echo esc_attr($theme_color); ?>"
     data-language="<?php echo esc_attr($default_language); ?>"
     data-show-events="<?php echo esc_attr($show_events); ?>"
     data-show-panchang="<?php echo esc_attr($show_panchang); ?>">
    <div class="hnp-loading">
        <div class="hnp-spinner"></div>
        <p><?php _e('Loading calendar...', 'hamro-nepali-patro'); ?></p>
    </div>
</div>