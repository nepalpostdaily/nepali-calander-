<?php
if (!defined('ABSPATH')) exit;

class Hamro_Nepali_Patro {
    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_get_events', [$this, 'get_events']);
        add_action('wp_ajax_nopriv_get_events', [$this, 'get_events']);
    }

    public function enqueue_scripts() {
        wp_enqueue_style('hamro-nepali-patro-style',
            HNP_PLUGIN_URL . 'public/css/hamro-nepali-patro-public.css', [], HNP_VERSION);
        wp_enqueue_script('hamro-nepali-patro-script',
            HNP_PLUGIN_URL . 'public/js/hamro-nepali-patro-public.js', ['jquery'], HNP_VERSION, true);
        wp_localize_script('hamro-nepali-patro-script', 'hnp_data', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('hnp_nonce'),
            'settings' => get_option('hnp_settings', []),
            'translations' => $this->get_translations()
        ]);
    }

    private function get_translations() {
        return [
            'months_ne' => ['बैशाख', 'जेठ', 'असार', 'साउन', 'भदौ', 'असोज', 'कार्तिक', 'मंसिर', 'पुष', 'माघ', 'फागुन', 'चैत्र'],
            'months_en' => ['Baisakh', 'Jestha', 'Ashar', 'Shrawan', 'Bhadra', 'Ashwin', 'Kartik', 'Mangsir', 'Poush', 'Magh', 'Falgun', 'Chaitra'],
            'days_short_ne' => ['आइत', 'सोम', 'मंगल', 'बुध', 'बिही', 'शुक्र', 'शनि'],
            'days_short_en' => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            'days_long_ne' => ['आइतबार', 'सोमबार', 'मंगलबार', 'बुधबार', 'बिहिबार', 'शुक्रबार', 'शनिबार'],
            'days_long_en' => ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
            'today_ne' => 'आज', 'today_en' => 'Today',
            'calendar_ne' => 'पात्रो', 'calendar_en' => 'Calendar',
            'converter_ne' => 'मिति रूपान्तरण', 'converter_en' => 'Date Converter',
            'panchang_ne' => 'पञ्चाङ्ग', 'panchang_en' => 'Panchang',
            'convert_ne' => 'रूपान्तरण गर्नुहोस्', 'convert_en' => 'Convert',
            'view_ne' => 'हेर्नुहोस्', 'view_en' => 'View',
        ];
    }

    public function get_events() {
        check_ajax_referer('hnp_nonce', 'nonce');
        $year = isset($_POST['year']) ? intval($_POST['year']) : 0;
        $month = isset($_POST['month']) ? intval($_POST['month']) : 0;
        if ($year < 2000 || $year > 2100 || $month < 0 || $month > 11) {
            wp_send_json_error('Invalid date');
        }
        global $wpdb;
        $table = $wpdb->prefix . 'hnp_events';
        $events = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM $table WHERE bs_year = %d AND bs_month = %d ORDER BY bs_day ASC", $year, $month),
            ARRAY_A
        );
        wp_send_json_success($events);
    }
}